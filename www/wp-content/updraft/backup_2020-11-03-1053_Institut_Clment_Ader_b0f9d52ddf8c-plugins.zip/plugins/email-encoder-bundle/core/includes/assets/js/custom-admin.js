/* Email Encoder Admin */
jQuery(function ($) {

    'use strict';

    // add form-table class to Encoder Form tables
    $('.eeb-form table').addClass('form-table');

});
